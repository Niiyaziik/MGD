<!doctype html>
<html lang="ru">
<link rel="stylesheet" href="/assets/main.css" />

<body>
        <div>
                <div class="site-body">
                        <div class="left-side">
                                <a href="/" class="logo-block__link" rel="noopener">
                                        <img class="logo-block__image"
                                                src="https://ugd.ru/local/templates/ugd/img/logo.png"
                                                alt="25 лет служим городу" title="25 лет служим городу">
                                </a>


                                <div class="left-side__soc">
                                        <a class="head-block__vk" href="https://vk.com/ulduma" target="_blank"></a>
                                        <a class="head-block__telegram" href="https://t.me/ugd73" target="_blank"
                                                rel="noopener"></a>
                                        <a class="head-block__email" href="mailto:duma@ugd.ru" rel="noopener"></a>
                                        <a class="head-block__ok" href="https://ok.ru/group/70000000957032"
                                                target="_blank" rel="noopener"></a>
                                        <a class="head-block__telephone" href="tel:+78422413800" rel="noopener"></a>

                                </div>
                                <nav class="left-side__navigation">
                                        <ul>
                                                <li><a href="/candidates/admin">Кандидаты</a></li>

                                                <li><a href="/districts/admin">Округа</a></li>

                                                <li><a href="/votes/admin">Проголосовавшие</a></li>

                                                <li><a href="/users/admin">БД пользователи</a></li>

                                                <li><a href="/candidates/admin/index">БД кандидаты</a></li>

                                                <li><a href="/districts/admin/index">БД округа</a></li>

                                                <li style="display: none;">Проголосовавшие</li>
                                        </ul>
                                </nav>
                        </div>
                        <main class="main">
                                <div id="candidates" class="content-list__content"
                                        style="display: flex; flex-wrap: wrap; justify-content: space-between;">
                                        <h2 id="district-title" class="content-list__districts_title">Проголосовавшие
                                        </h2>
                                </div>

                                <div id="district-bounds" class="bounds">
                                </div>
                        </main>
                </div>

                <footer class="footer">

                        <div class="footer__body">
                                <ul class="footer__menu">
                                        <li class="footer__menu-item"><span class="title">О думе</span> <img
                                                        src="/local/templates/ugd/img/blocks/bley-arrow.png"
                                                        class="footer__arrow" alt="" title="">
                                        </li>
                                        <li class="footer__menu-item"><a class="footer__menu-link" href="/about/"
                                                        onclick="openTab2(event, 'history')">История</a></li>
                                        <li class="footer__menu-item"><a class="footer__menu-link"
                                                        href="/about/#structure"
                                                        onclick="openTab2(event, 'structure')">Структура</a></li>
                                        <li class="footer__menu-item"><a class="footer__menu-link"
                                                        href="/about/#apparat"
                                                        onclick="openTab2(event, 'apparat')">Аппарат УГД</a></li>
                                        <li class="footer__menu-item"><a class="footer__menu-link"
                                                        href="/about/#reglament"
                                                        onclick="openTab2(event, 'reglament')">Регламент</a></li>
                                        <li class="footer__menu-item"><a class="footer__menu-link"
                                                        href="/about/#service"
                                                        onclick="openTab2(event, 'service')">Муниципальная служба</a>
                                        </li>
                                        <li class="footer__menu-item"><a class="footer__menu-link"
                                                        href="/main_news/">Новости</a></li>
                                        <br>
                                        <li class="footer__menu-item"><span class="title">Депутаты</span></li>
                                        <li class="footer__menu-item"><a class="footer__menu-link" href="/dep/">Состав
                                                        думы VI созыва</a>
                                        </li>
                                        <!--<li class="footer__menu-item"><a class="footer__menu-link" href="#">Благодарности депутатам</a></li>-->
                                </ul>
                                <ul class="footer__menu">
                                        <li class="footer__menu-item"><span class="title">Деятельность</span> <img
                                                        src="/local/templates/ugd/img/blocks/bley-arrow.png"
                                                        class="footer__arrow" alt="" title="">
                                        </li>
                                        <li class="footer__menu-item"><a class="footer__menu-link"
                                                        href="/docs/#solutions">Решения</a></li>
                                        <li class="footer__menu-item"><a class="footer__menu-link"
                                                        href="/docs/#resolutions">Постановления</a></li>
                                        <li class="footer__menu-item"><a class="footer__menu-link"
                                                        href="/docs/#glava-gor-resolutions">Постановления Главы
                                                        города</a></li>
                                        <li class="footer__menu-item"><a class="footer__menu-link"
                                                        href="/docs/#glava-gor-orders">Распоряжения Главы города</a>
                                        </li>
                                        <li class="footer__menu-item"><a class="footer__menu-link"
                                                        href="/docs/#appealnpa">Порядок
                                                        обжалования НПА УГД</a></li>
                                        <li class="footer__menu-item"><a class="footer__menu-link"
                                                        href="/docs/#other-documents">Документы</a></li>
                                        <li class="footer__menu-item"><a class="footer__menu-link"
                                                        href="/docs/#ocherednoe-zasedanie">Очередное заседание</a></li>
                                        <li class="footer__menu-item"><a class="footer__menu-link"
                                                        href="/docs/#plan-raboty-2022">План
                                                        работы на I полугодие 2023 г.</a></li>
                                        <li class="footer__menu-item"><a class="footer__menu-link"
                                                        href="/docs/#plan_raboty2">План работы на
                                                        октябрь 2023 г.</a></li>
                                        <li class="footer__menu-item"><a class="footer__menu-link"
                                                        href="/about/#korrupt">Противодействие
                                                        коррупции</a></li>
                                        <li class="footer__menu-item"><a class="footer__menu-link"
                                                        href="/docs/#projecty_documentov">Проекты
                                                        документов</a></li>
                                </ul>
                                <ul class="footer__menu">
                                        <li class="footer__menu-item"><span class="title">Приемная</span> <img
                                                        src="/local/templates/ugd/img/blocks/bley-arrow.png"
                                                        class="footer__arrow" alt="" title="">
                                        </li>
                                        <li class="footer__menu-item"><a class="footer__menu-link"
                                                        href="/reception/">Работа с обращениями
                                                        граждан</a></li>
                                        <li class="footer__menu-item"><a class="footer__menu-link"
                                                        href="/reception/#graphik">График приема
                                                        избирателей депутатами УГД в общественной приёмной</a></li>
                                        <br>
                                        <li class="footer__menu-item"><span class="title">Комитеты</span></li>
                                        <li class="footer__menu-item"><a class="footer__menu-link"
                                                        href="/committees/">Состав комитетов</a>
                                        </li>
                                        <li class="footer__menu-item"><a class="footer__menu-link"
                                                        href="/committees/#rabota-komitetov">Работа комитетов</a></li>
                                        <li class="footer__menu-item"><a class="footer__menu-link"
                                                        href="/committees/#arhiv-povestok">Архив
                                                        повесток заседаний комитетов</a></li>
                                </ul>
                                <ul class="footer_contact_all">
                                        <p class="footer_copyrigt">© 2025 Ульяновская Городская Дума</p>
                                        <p class="footer_addr">ул. Кузнецова, 7</p>
                                        <p class="footer_phone">Телефон: (8422) 41-38-00</p>
                                        <p class="footer_mail">e-mail: <a href="mailto:duma@ugd.ru">duma@ugd.ru</a></p>
                                        <p class="footer_personal"><a target="_blank"
                                                        href="/upload/politica-2018.pdf">Политика в отношении
                                                        обработки персональных данных</a></p>
                                </ul>
                                <!--
        <ul class="footer__menu">
            <li class="footer__menu-item"><span class="title">О городе</span> <img src="/local/templates/ugd/img/blocks/bley-arrow.png" class="footer__arrow" alt="" title=""></li>
        </ul>
    -->
                        </div>
                </footer>
                <div class="footer-copyright-design">
                        <div class="container">Разработано в <a href="http://agatech.ru/" target="_blank"
                                        title="agatech.ru">AGATECH</a></div>
                </div>
                <script src="/js/votes.js"></script>
</body>

</html>